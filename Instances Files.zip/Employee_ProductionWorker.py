"""Mallory Milstead
   5/1/2018
   CSC-121
   This program imports a file with a superclass and subclass and creates objects"""

#Import the file.
import workers

def show_data(employeeList):
    print ("EMPLOYEES")
    for employee in employeeList:
        print (employee.getData())

def main():

    toAdd = int(input("How many employees will you add? "))
    print("\n")

    #Create an empty list.
    employeeList = []

    #Create a for loop to control how many objects to create.
    for i in range (0,toAdd):

        #Get input from user for attributes.
        name = input("Enter the employee name: ")
        number = input("Enter the employee ID number: ")
        shift = input("Enter the shift the employee will work: ")
        payRate = input("Enter the employee's pay rate: ")
        print("\n")

        #Create the object.
        employee = workers.ProductionWorker(name, number, shift, payRate)

        #Add the object to the list.
        employeeList.append(employee)

    show_data(employeeList)


if __name__ == "__main__":
    main()
        
    
