"""Mallory Milstead
   5/4/2018
   CSC-121
   This program uses a subclass(ShiftSupervisor) of the Employee class to determine each supervisor's total salary and bonus"""

#import the file
import workers

print("This program determines the bonus and total annual pay for Supervisors.")
print("Supervisors recieve a bonus of 15% of their annual salary.")
print()

def show_data(superList):
    print ("SUPERVISOR SALARIES")
    for each in superList:
        print (each.getData())


#Create an empty list to put the objects in.
superList = []

#Variable to control the loop.
again = "y"
while again.lower() == "y":
    #Get input from user for attributes.
        name = input("Enter the supervisor's name: ")
        number = input("Enter the  ID number: ")
        salary = float(input("Enter their annual salary: "))
        print("\n")

        #Create the object.
        supers = workers.ShiftSupervisor(name, number, salary, salary*.15)

        #Add the object to the list.
        superList.append(supers)

        again = str(input("Would you like to add another Supervisor? (y/n) "))
while again.lower() != "y":
    show_data(superList)
    break
