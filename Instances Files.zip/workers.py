"""Mallory Milstead
   5/1/18
   CSC-121
   This is a class and subclass that will be used in a program."""

#This is the superclass.

class Employee:

    #Initalize the attributes.
    def __init__(self, name, number):
        self.__name = name
        self.__number = number

    #Mutator methods.
    def setName(self, name):
        self.__name = name

    def setNumber(self, number):
        self.__number = number

    #Return the name attribute.
    def getName(self):
        return self.__name

    #Return the number attribute.
    def getNum (self):
        return self.__number

    def getData(self):
        return "Name: " + self.__name + "\n" \
               "Employee ID: " + self.__number + "\n" \

#This is a subclass.

class ProductionWorker(Employee):
    def __init__ (self, name, number, shift, payRate):

        #Call the constructor of the superclass.
        Employee.__init__(self, name, number)

        #Initialize the new attirbues of the subclass.
        self.__shift = shift
        self.__payRate = payRate

    #Set the mutator methods for the attributes of the subclass.
        def setShift(self, shift):
            self.__shift = shift

        def setpayRate(self, payRate):
            self.__payRate = payRate


    #Return the shift attribute.
    def getShift(self):
        return self.__shift

    #Return the payRate attribute.
    def getpayRate(self):
        return (self.__payRate)

    #Return all data for an object.
    def getData(self):
        return Employee.getData(self) + "Shift: " + self.__shift + "\n" \
               "Pay Rate:" + "${:,.2f}".format(float(self.__payRate)) + "\n" + "\n"

#This is a subclass.

#Here you list all the attributes of the class, the ones from the superclass and the new ones that will be part of the subclass.
class ShiftSupervisor(Employee):
    def __init__(self, name, number, salary, bonus):
        #Here you are initializing the attributes from the superclass.Notice the syntax SUPERCLASS.__init__(attributes from the superclass)
        Employee.__init__(self, name, number)

        #Initialize the new attributes of the subclass.
        self.__salary = salary
        self.__bonus = bonus

    #Get (accessor) and set (mutator) methods for the Salary attribute.
    def setSalary(self, salary):
        self.__salary = salary

    def getSalary(self):
        return self.__salary

    #Get (accessor) and set (mutator) methods for the Salary attribute.
    def setBonus(self, bonus):
        self.__bonus = bonus

    def getBonus(self):
        return self.__bonus
    

    def getData(self):
        total = float(self.__salary) + float(self.__bonus)
        return Employee.getData(self)  + \
               "Salary: " + "${:,.2f}".format(float(self.__salary)) + "\n" \
               "Bonus:" + "${:,.2f}".format(float(self.__bonus)) + "\n" \
               "Total Compensation: " + "${:,.2f}".format(float(total))

    
